//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"



var suits = ["♠︎", "♣︎", "♥︎", "♦︎"]
var ranks = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
// create 2 array- suits and ranks
var number = ""
var suit = ""

var card = suit + number
// create variables to store values for further use. 

var fullDeck: [String] = []
// create the end result which is an array of full deck with 52 cards 


for x in suits {
    suit = "\(x)"
    for y in ranks {
        number = "\(y)"
    
    
        card = suit + number
            fullDeck.append(card)
            
    }
        }

// create a nested for loops, first to set the suits and second for rank 
// finally create the card and then add it to the array of fullDeck using .append

print(card)
// to confirm that a card is created

print(fullDeck)
// to confirm that all 52 cards are in the deck 

fullDeck.count
// take a count of the cards.


import Foundation

// import foundation to allow for use of arc4random function

let randomIndex = Int(arc4random_uniform(UInt32(fullDeck.count)))
// create a integer number to be used as the random index number of fulldeck array
let randomCard1 = fullDeck[randomIndex]
// assign constant randomCard to draw first random card.
    fullDeck.removeAtIndex(randomIndex)
// remove the drawn card from the deck to eliminate duplicates.
let randomIndex2 = Int(arc4random_uniform(UInt32(fullDeck.count)))
// create second random index.
let randomCard2 = fullDeck[randomIndex2]
// use random index to draw second random card
    fullDeck.removeAtIndex(randomIndex2)
// remove the second random card from deck
let randomIndex3 = Int(arc4random_uniform(UInt32(fullDeck.count)))
// create third random index
let randomCard3 = fullDeck[randomIndex3]
// use random index to draw third random card
    fullDeck.removeAtIndex(randomIndex3)
// remove third random card from deck
        print(fullDeck)
// print to confirm missing cards from deck
        fullDeck.count
// count the cards to confirm three cards have been drawn 












